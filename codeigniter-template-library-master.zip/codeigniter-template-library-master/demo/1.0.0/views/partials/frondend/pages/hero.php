<div class="hero-unit">
	<h1><?php echo $title; ?></h1>
	<p>This is a template for a simple marketing or informational website. It includes a large callout called the hero unit and three supporting pieces of content. Use it as a starting point to create something more unique.</p>
	<p><a class="btn btn-primary btn-large">Learn more &raquo;</a></p>
</div>