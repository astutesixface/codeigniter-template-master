 <?php
		// Dynamically add a css stylesheet
		$this->template->stylesheet->add('http://twitter.github.com/bootstrap/assets/css/bootst.css');		
	?>
	<style>
	p{
		font-size:50px;
		
	}
	</style>